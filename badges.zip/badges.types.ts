// Bajet Buddy — Badge types
// Generated to match badges.json schema. Import into apps/web/lib/badges.ts.

export type BadgeCategory = "streak" | "saving" | "behaviour" | "persona" | "level";
export type BadgeTier = "bronze" | "silver" | "gold" | "platinum";

export type UnlockRule =
  | { type: "streak_length"; value: number }
  | { type: "lifetime_saved"; value: number }
  | { type: "first_event"; event: string }
  | { type: "category_under_budget_week"; category: string; value: number }
  | { type: "no_bnpl_calendar_month" }
  | { type: "budget_categories_set"; value: number }
  | { type: "feature_first_use"; feature: string }
  | { type: "persona_detected"; persona_slug: string }
  | { type: "persona_reformed"; persona_slug: string; value: number }
  | { type: "level_reached"; value: number }
  | { type: "avoided_midnight_purchase" }
  | { type: "total_avoided_count"; value: number };

export interface Badge {
  slug: string;
  name: string;        // Malay / primary
  name_en: string;     // English
  icon_emoji: string;
  category: BadgeCategory;
  tier: BadgeTier;
  description: string;
  unlock_rule: UnlockRule;
  xp_reward: number;
  freeze_reward: number;
  is_secret: boolean;
}

export interface UserBadgeProgress {
  badge_slug: string;
  unlocked: boolean;
  unlocked_at?: string;     // ISO timestamp when unlocked
  progress_current?: number; // e.g. current lifetime_saved
  progress_target?: number;  // e.g. target lifetime_saved
  progress_label?: string;   // e.g. "RM73 / RM100 saved"
}

// XP → Level helper. Mirror this in the backend.
export function levelFromXp(totalXp: number): number {
  return Math.floor(totalXp / 500) + 1;
}

export function xpToNextLevel(totalXp: number): { current: number; needed: number; level: number } {
  const level = levelFromXp(totalXp);
  const xpAtLevelStart = (level - 1) * 500;
  return {
    current: totalXp - xpAtLevelStart,
    needed: 500,
    level,
  };
}

// Tier ordering for sorting/filtering
export const TIER_ORDER: Record<BadgeTier, number> = {
  bronze: 1,
  silver: 2,
  gold: 3,
  platinum: 4,
};

// Category display labels (extend with i18n if needed)
export const CATEGORY_LABELS: Record<BadgeCategory, { ms: string; en: string }> = {
  streak:    { ms: "Streak",          en: "Streak" },
  saving:    { ms: "Simpanan",        en: "Saving" },
  behaviour: { ms: "Tabiat",          en: "Behaviour" },
  persona:   { ms: "Persona",         en: "Persona" },
  level:     { ms: "Tahap",           en: "Level" },
};
