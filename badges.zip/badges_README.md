# Bajet Buddy — Badge Catalogue Seed

Three files that together seed the badge collection feature.

## Files

| File | Purpose | Where it goes |
|---|---|---|
| `badges.json` | Source of truth — 33 badges with unlock rules | `packages/shared/seed/badges.json` |
| `badges_seed.sql` | Postgres/Supabase schema + seed inserts | `apps/api/migrations/002_badges_seed.sql` |
| `badges.types.ts` | TypeScript types + XP→level helpers | `packages/shared/types/badges.ts` |

## Quick facts

- **33 badges** total across 5 categories
  - 7 streak (Hari Pertama → 100 Hari Hero)
  - 6 saving (First Save → Sultan Simpan)
  - 8 behaviour (Tidur Awal, Mamak Hero, BNPL-Free Month, etc.)
  - 8 persona (4 "detected" personas + 4 "reformed" twin badges)
  - 4 level milestones (Bronze → Diamond)
- **4 tiers** (bronze / silver / gold / platinum) for visual treatment
- **XP rewards** range from 0 (pure level badges) to 1500 (Sultan Simpan, 100 Hari Hero)
- **Freeze rewards** earned from select badges to protect streaks
- **1 secret badge** (Diamond Disciplined, Level 50) — hidden from collection grid until unlocked

## How the unlock pipeline works

```
User action (log transaction / avoid purchase / hit milestone)
     ↓
Backend updates user_streaks / user_xp / intervention_events
     ↓
POST /api/badges/check-unlocks
     ↓
Service iterates badges WHERE NOT IN user_badges for this user
     ↓
For each, evaluates unlock_rule against user state
     ↓
INSERT INTO user_badges (user_id, badge_id) for matches
     ↓
Returns list of newly unlocked badges → frontend triggers reveal modal
```

## Unlock rule types reference

| Type | Required fields | Meaning |
|---|---|---|
| `streak_length` | `value` | `user_streaks.current_streak >= value` |
| `lifetime_saved` | `value` | sum of saved_amount from intervention_events ≥ value (RM) |
| `first_event` | `event` | First time a named event occurs (e.g. `transaction_logged`) |
| `category_under_budget_week` | `category`, `value` | Stay under budget for `value` days within a rolling 7-day window |
| `no_bnpl_calendar_month` | — | A full calendar month with zero new bnpl_commitments rows |
| `budget_categories_set` | `value` | Active budget rows across ≥ value distinct categories |
| `feature_first_use` | `feature` | First use of a named feature (e.g. `add_buddy`, `create_lock`) |
| `persona_detected` | `persona_slug` | A matching spending_personas row exists |
| `persona_reformed` | `persona_slug`, `value` | Persona pattern absent for `value` days after being detected |
| `level_reached` | `value` | `user_xp.current_level >= value` |
| `avoided_midnight_purchase` | — | First JANGAN_DULU/FIKIR_DULU accepted between 22:00–02:00 |
| `total_avoided_count` | `value` | Count of intervention_events with saved_amount > 0 ≥ value |

## Adding a new badge

1. Append an entry to `badges.json`
2. Re-run `python3 generate_sql.py` to regenerate `badges_seed.sql`
3. Apply the new SQL (the inserts use `ON CONFLICT (slug) DO UPDATE` so they're idempotent — running the file twice is safe)
4. If the unlock rule type is new, add the corresponding handler in the `check-unlocks` service and a new variant in `badges.types.ts`

## XP → Level formula

```ts
level = Math.floor(total_xp / 500) + 1
```

So Level 5 = 2000+ XP, Level 10 = 4500+ XP, Level 20 = 9500+ XP, Level 50 = 24500+ XP.

Mirror this exact formula on backend (Python) and frontend (TypeScript). It's in `badges.types.ts` as `levelFromXp()`.

## Demo seed for Sarah

For the hackathon demo, pre-unlock a few badges on Sarah's profile to make the collection grid feel populated when judges open it:

```sql
INSERT INTO user_badges (user_id, badge_id)
SELECT '<sarah-uuid>', id FROM badges
WHERE slug IN ('hari-pertama', 'tiga-hari-tegar', 'budget-boss', 'midnight-shopee-queen');

INSERT INTO user_xp (user_id, total_xp, current_level)
VALUES ('<sarah-uuid>', 425, 1);
```

Then during the live demo, Sarah saves RM189 on the checkout simulator → that triggers `first-save` + `tidur-awal` unlocks live on stage. Visual payoff confirmed.
