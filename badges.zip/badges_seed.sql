-- =========================================================
-- Bajet Buddy — Badges seed (Postgres / Supabase)
-- Generated from badges.json
-- =========================================================

-- SCHEMA

CREATE TABLE IF NOT EXISTS badges (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug            text UNIQUE NOT NULL,
  name            text NOT NULL,
  name_en         text NOT NULL,
  icon_emoji      text NOT NULL,
  category        text NOT NULL CHECK (category IN ('streak','saving','behaviour','persona','level')),
  tier            text NOT NULL CHECK (tier IN ('bronze','silver','gold','platinum')),
  description     text NOT NULL,
  unlock_rule     jsonb NOT NULL,
  xp_reward       integer NOT NULL DEFAULT 0,
  freeze_reward   integer NOT NULL DEFAULT 0,
  is_secret       boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_badges (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id     uuid NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  unlocked_at  timestamptz NOT NULL DEFAULT now(),
  progress     jsonb,
  UNIQUE (user_id, badge_id)
);
CREATE INDEX IF NOT EXISTS idx_user_badges_user ON user_badges(user_id);

CREATE TABLE IF NOT EXISTS user_xp (
  user_id           uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  total_xp          integer NOT NULL DEFAULT 0,
  current_level     integer NOT NULL DEFAULT 1,
  last_xp_event_at  timestamptz
);

CREATE TABLE IF NOT EXISTS user_streaks (
  user_id              uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  current_streak       integer NOT NULL DEFAULT 0,
  longest_streak       integer NOT NULL DEFAULT 0,
  last_log_date        date,
  freeze_count         integer NOT NULL DEFAULT 0,
  total_logs_lifetime  integer NOT NULL DEFAULT 0
);

-- =========================================================
-- SEED DATA
-- =========================================================

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('hari-pertama', 'Hari Pertama', 'First Day', '🔥', 'streak', 'bronze', 'Log your first transaction in Bajet Buddy.', '{"type": "first_event", "event": "transaction_logged"}'::jsonb, 25, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('tiga-hari-tegar', 'Tiga Hari Tegar', 'Three Day Determined', '🔥', 'streak', 'bronze', 'Log transactions 3 days in a row.', '{"type": "streak_length", "value": 3}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('seminggu-setia', 'Seminggu Setia', 'Week of Loyalty', '🔥', 'streak', 'silver', 'Log transactions 7 days in a row.', '{"type": "streak_length", "value": 7}'::jsonb, 150, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('streak-saver', 'Streak Saver', 'Streak Saver', '❄️', 'streak', 'silver', 'Reach a 14-day streak and earn 1 Streak Freeze.', '{"type": "streak_length", "value": 14}'::jsonb, 200, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('sebulan-steady', 'Sebulan Steady', 'Steady Month', '🔥', 'streak', 'gold', 'Log transactions 30 days in a row.', '{"type": "streak_length", "value": 30}'::jsonb, 500, 2, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('lima-puluh-konsisten', 'Lima Puluh Konsisten', 'Fifty Day Consistent', '🔥', 'streak', 'gold', 'Log transactions 50 days in a row.', '{"type": "streak_length", "value": 50}'::jsonb, 750, 2, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('seratus-hari-hero', '100 Hari Hero', '100 Day Hero', '🔥', 'streak', 'platinum', 'Log transactions 100 days in a row. Legend status.', '{"type": "streak_length", "value": 100}'::jsonb, 1500, 3, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('first-save', 'First Save', 'First Save', '💰', 'saving', 'bronze', 'Avoid your first impulse purchase.', '{"type": "total_avoided_count", "value": 1}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('rm100-saved', 'RM100 Saved', 'RM100 Saved', '💰', 'saving', 'bronze', 'Avoid RM100 in lifetime impulse spending.', '{"type": "lifetime_saved", "value": 100}'::jsonb, 100, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('rm500-saved', 'RM500 Saved', 'RM500 Saved', '💰', 'saving', 'silver', 'Avoid RM500 in lifetime impulse spending.', '{"type": "lifetime_saved", "value": 500}'::jsonb, 250, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('rm1000-saved', 'RM1,000 Saved', 'RM1,000 Saved', '💰', 'saving', 'gold', 'Avoid RM1,000 in lifetime impulse spending.', '{"type": "lifetime_saved", "value": 1000}'::jsonb, 500, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('sultan-simpan', 'Sultan Simpan', 'Sultan of Savings', '💎', 'saving', 'platinum', 'Avoid RM5,000 in lifetime impulse spending. You''re royalty.', '{"type": "lifetime_saved", "value": 5000}'::jsonb, 1500, 3, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('ten-saves-club', '10 Saves Club', '10 Saves Club', '🏆', 'saving', 'silver', 'Avoid 10 impulse purchases.', '{"type": "total_avoided_count", "value": 10}'::jsonb, 200, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('tidur-awal', 'Tidur Awal', 'Early Sleeper', '🌙', 'behaviour', 'silver', 'Avoid a midnight Shopee purchase between 10PM and 2AM.', '{"type": "avoided_midnight_purchase"}'::jsonb, 100, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('mamak-hero', 'Mamak Hero', 'Mamak Hero', '🍜', 'behaviour', 'silver', 'Stay under your food budget 5 out of 7 days in a week.', '{"type": "category_under_budget_week", "category": "food", "value": 5}'::jsonb, 150, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('bnpl-free-month', 'BNPL-Free Month', 'BNPL-Free Month', '💳', 'behaviour', 'gold', 'Complete a full calendar month with zero new BNPL commitments.', '{"type": "no_bnpl_calendar_month"}'::jsonb, 300, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('budget-boss', 'Budget Boss', 'Budget Boss', '📊', 'behaviour', 'bronze', 'Set up budgets across all 5 spending categories.', '{"type": "budget_categories_set", "value": 5}'::jsonb, 100, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('buddy-up', 'Buddy Up', 'Buddy Up', '🤝', 'behaviour', 'bronze', 'Add your first accountability buddy.', '{"type": "feature_first_use", "feature": "add_buddy"}'::jsonb, 75, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('lock-and-load', 'Lock & Load', 'Lock & Load', '🔒', 'behaviour', 'bronze', 'Create your first Belanja Lock.', '{"type": "feature_first_use", "feature": "create_lock"}'::jsonb, 75, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('simulator-thinker', 'Simulator Thinker', 'Simulator Thinker', '🔮', 'behaviour', 'bronze', 'Run your first Future You simulation before a big purchase.', '{"type": "feature_first_use", "feature": "run_simulation"}'::jsonb, 75, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('cooling-off-champion', 'Cooling Off Champion', 'Cooling Off Champion', '🧊', 'behaviour', 'silver', 'Complete a 24-hour cooling-off period and decide not to buy.', '{"type": "feature_first_use", "feature": "cooling_off_completed"}'::jsonb, 200, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('midnight-shopee-queen', 'Midnight Shopee Queen', 'Midnight Shopee Queen', '👑', 'persona', 'bronze', 'You''ve been identified as a Midnight Shopee Queen. Awareness is the first step.', '{"type": "persona_detected", "persona_slug": "midnight_shopee_queen"}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('reformed-night-owl', 'Reformed Night Owl', 'Reformed Night Owl', '🌙', 'persona', 'gold', '14 days with no midnight purchases after being a Midnight Shopee Queen.', '{"type": "persona_reformed", "persona_slug": "midnight_shopee_queen", "value": 14}'::jsonb, 400, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('gaji-habis-king', 'Gaji Habis King', 'Gaji Habis King', '👑', 'persona', 'bronze', 'Detected: 60%+ of salary spent within 3 days of payday.', '{"type": "persona_detected", "persona_slug": "gaji_habis_king"}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('payday-pacer', 'Payday Pacer', 'Payday Pacer', '🚶', 'persona', 'gold', 'Spent less than 30% of salary in the first 3 days post-payday for 2 cycles.', '{"type": "persona_reformed", "persona_slug": "gaji_habis_king", "value": 60}'::jsonb, 400, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('mamak-lepak-spender', 'Mamak Lepak Spender', 'Mamak Lepak Spender', '☕', 'persona', 'bronze', 'Detected: high concentration of mamak / lepak spending.', '{"type": "persona_detected", "persona_slug": "mamak_lepak_spender"}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('mindful-lepaker', 'Mindful Lepaker', 'Mindful Lepaker', '🧘', 'persona', 'gold', 'Stayed under your lepak budget for 4 weeks running.', '{"type": "persona_reformed", "persona_slug": "mamak_lepak_spender", "value": 28}'::jsonb, 400, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('bnpl-roller', 'BNPL Roller', 'BNPL Roller', '🎲', 'persona', 'bronze', 'Detected: 3+ active BNPL commitments at once.', '{"type": "persona_detected", "persona_slug": "bnpl_roller"}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('bubble-tea-bro', 'Bubble Tea Bro', 'Bubble Tea Bro', '🧋', 'persona', 'bronze', 'Detected: high bubble tea / beverage spending pattern.', '{"type": "persona_detected", "persona_slug": "bubble_tea_bro"}'::jsonb, 50, 0, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('bronze-bajeter', 'Bronze Bajeter', 'Bronze Bajeter', '🥉', 'level', 'bronze', 'Reach Level 5.', '{"type": "level_reached", "value": 5}'::jsonb, 0, 1, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('silver-saver', 'Silver Saver', 'Silver Saver', '🥈', 'level', 'silver', 'Reach Level 10.', '{"type": "level_reached", "value": 10}'::jsonb, 0, 2, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('gold-guardian', 'Gold Guardian', 'Gold Guardian', '🥇', 'level', 'gold', 'Reach Level 20.', '{"type": "level_reached", "value": 20}'::jsonb, 0, 3, false)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

INSERT INTO badges (slug, name, name_en, icon_emoji, category, tier, description, unlock_rule, xp_reward, freeze_reward, is_secret) VALUES
  ('diamond-disciplined', 'Diamond Disciplined', 'Diamond Disciplined', '💎', 'level', 'platinum', 'Reach Level 50. The top of the leaderboard.', '{"type": "level_reached", "value": 50}'::jsonb, 0, 5, true)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  name_en = EXCLUDED.name_en,
  icon_emoji = EXCLUDED.icon_emoji,
  category = EXCLUDED.category,
  tier = EXCLUDED.tier,
  description = EXCLUDED.description,
  unlock_rule = EXCLUDED.unlock_rule,
  xp_reward = EXCLUDED.xp_reward,
  freeze_reward = EXCLUDED.freeze_reward,
  is_secret = EXCLUDED.is_secret;

-- =========================================================
-- Total badges seeded: 33
--   behaviour: 8
--   level: 4
--   persona: 8
--   saving: 6
--   streak: 7
-- =========================================================
